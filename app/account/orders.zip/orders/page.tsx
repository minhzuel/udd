'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Eye, 
  Search, 
  Calendar, 
  Filter, 
  ChevronLeft, 
  ChevronRight,
  Download,
  ShoppingBag,
  Package2,
  ChevronsLeft,
  ChevronsRight
} from 'lucide-react'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { DateRange } from "react-day-picker"
import { toast } from "sonner"
import Image from "next/image"
import { buttonVariants } from "@/components/ui/button"

interface OrderPayment {
  paymentMethod: string
}

interface ProductDetails {
  id: number
  name: string
  mainImage: string
}

interface VariationCombination {
  id: number
  imageUrl: string | null
  price: string | null
  variation1: {
    name: string
    value: string
  }
  variation2?: {
    name: string
    value: string
  } | null
  variation3?: {
    name: string
    value: string
  } | null
}

interface OrderItem {
  id: number
  productId: number | null
  quantity: number | null
  itemPrice: string | null
  product: ProductDetails | null
  product_variation_combinations: VariationCombination | null
  variationDetails: string | null
}

interface Order {
  id: number
  orderDate: string | null
  totalAmount: string | null
  orderStatus: string | null
  shippingMethod: string | null
  fullName: string | null
  payments: OrderPayment[]
  orderItems: OrderItem[]
  shippingAddress: {
    id: number
    fullName: string | null
    mobileNo: string | null
    address: string | null
    city: string | null
  } | null
  billingAddress: {
    id: number
    fullName: string | null
    mobileNo: string | null
    address: string | null
    city: string | null
  } | null
  orderNumber: number | null
}

const orderStatuses = [
  { value: 'ALL', label: 'All Statuses' },
  { value: 'PENDING', label: 'Pending' },
  { value: 'PROCESSING', label: 'Processing' },
  { value: 'SHIPPED', label: 'Shipped' },
  { value: 'DELIVERED', label: 'Delivered' },
  { value: 'CANCELLED', label: 'Cancelled' },
]

export default function OrdersPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [userAddresses, setUserAddresses] = useState<Array<{
    id: number;
    fullName: string | null;
    mobileNo: string | null;
    address: string | null;
    city: string | null;
    isDefault?: boolean;
  }>>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: undefined,
    to: undefined,
  });
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        
        // Build query params for filtering by status
        let url = '/api/user/orders';
        if (statusFilter && statusFilter !== 'ALL') {
          url += `?status=${statusFilter}`;
        }
        
        console.log('Fetching orders from:', url);
        
        const response = await fetch(url);
        if (!response.ok) {
          // Try to get more detailed error information
          let errorMessage = 'Failed to fetch orders';
          try {
            const errorData = await response.json();
            if (errorData.message) {
              errorMessage = errorData.message;
            } else if (errorData.error) {
              errorMessage = errorData.error;
            }
            console.error('Order API error:', errorData);
          } catch (parseError) {
            console.error('Error parsing error response:', parseError);
          }
          
          throw new Error(errorMessage);
        }
        
        const data = await response.json();
        
        // Validate the response structure
        if (!data || !data.orders || !Array.isArray(data.orders)) {
          console.error('Unexpected API response format:', data);
          throw new Error('Invalid response format from server');
        }
        
        console.log(`Successfully loaded ${data.orders.length} orders`);
        
        setOrders(data.orders || []);
        setFilteredOrders(data.orders || []);
        
        // Save user addresses
        if (data.userAddresses) {
          setUserAddresses(data.userAddresses);
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching orders:', error);
        toast.error(error instanceof Error ? error.message : 'Failed to load orders');
        setLoading(false);
        setOrders([]);
        setFilteredOrders([]);
      }
    };

    fetchOrders();
  }, [statusFilter]);

  // Update to handle non-array order items
  const ordersHaveItems = (order: Order) => {
    if (!order.orderItems) return false;
    if (!Array.isArray(order.orderItems)) return false;
    return order.orderItems.length > 0;
  }

  // Update to safely handle missing data
  const getItemImage = (orderItem: OrderItem): string => {
    // Check if orderItem exists
    if (!orderItem) return '';
    
    // First try to get the variation combination image
    if (orderItem.product_variation_combinations?.imageUrl) {
      return orderItem.product_variation_combinations.imageUrl;
    }
    
    // Then try to get the product image
    if (orderItem.product?.mainImage) {
      return orderItem.product.mainImage;
    }
    
    // If still no image, check variationDetails (legacy format)
    if (orderItem.variationDetails) {
      try {
        const details = JSON.parse(orderItem.variationDetails);
        if (details.image) {
          return details.image;
        }
      } catch (e) {
        // If parsing fails, ignore and use fallback
      }
    }
    
    // Fallback - no image available
    return '';
  };

  // Add try-catch for filtering logic to avoid breaking if data has issues
  useEffect(() => {
    try {
      let result = [...orders];

      // Filter by date range
      if (dateRange?.from) {
        result = result.filter(order => {
          if (!order.orderDate) return false;
          try {
            const orderDate = new Date(order.orderDate);
            return orderDate >= dateRange.from!;
          } catch (e) {
            return false;
          }
        });
      }

      if (dateRange?.to) {
        result = result.filter(order => {
          if (!order.orderDate) return false;
          try {
            const orderDate = new Date(order.orderDate);
            return orderDate <= dateRange.to!;
          } catch (e) {
            return false;
          }
        });
      }

      // Apply search filter - more safely
      if (searchTerm) {
        result = result.filter(order => {
          try {
            // Check ID
            if (order.id && order.id.toString().includes(searchTerm)) return true;
            
            // Check full name
            if (order.fullName && order.fullName.toLowerCase().includes(searchTerm.toLowerCase())) return true;
            
            // Check items only if they exist and are an array
            if (ordersHaveItems(order)) {
              return order.orderItems.some(item => 
                item.product?.name?.toLowerCase().includes(searchTerm.toLowerCase())
              );
            }
            
            return false;
          } catch (e) {
            console.error('Error filtering order:', e);
            return false;
          }
        });
      }

      setFilteredOrders(result);
      setCurrentPage(1); // Reset to first page when filters change
    } catch (error) {
      console.error('Error filtering orders:', error);
      setFilteredOrders(orders); // Fall back to unfiltered orders
    }
  }, [orders, dateRange, searchTerm]);

  const getStatusColor = (status: string | null) => {
    if (!status) return 'bg-gray-500';
    
    const statusMap: Record<string, string> = {
      'PENDING': 'bg-yellow-500',
      'PROCESSING': 'bg-blue-500',
      'SHIPPED': 'bg-purple-500',
      'DELIVERED': 'bg-green-500',
      'CANCELLED': 'bg-red-500',
    };
    return statusMap[status] || 'bg-gray-500';
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: string | null) => {
    if (!amount) return '$0.00';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(parseFloat(amount));
  };

  // Generate a formatted variation string from the variation combination
  const getVariationString = (combination: VariationCombination | null): string => {
    if (!combination) return '';
    
    const variations = [];
    
    if (combination.variation1) {
      variations.push(`${combination.variation1.name}: ${combination.variation1.value}`);
    }
    
    if (combination.variation2) {
      variations.push(`${combination.variation2.name}: ${combination.variation2.value}`);
    }
    
    if (combination.variation3) {
      variations.push(`${combination.variation3.name}: ${combination.variation3.value}`);
    }
    
    return variations.join(', ');
  };

  // Get payment method from the first payment
  const getPaymentMethod = (order: Order): string => {
    if (order.payments && order.payments.length > 0 && order.payments[0].paymentMethod) {
      return order.payments[0].paymentMethod;
    }
    return 'N/A';
  };

  // Get address display text
  const getAddressText = (addressId: number | null) => {
    if (!addressId) return null;
    
    const address = userAddresses.find(addr => addr.id === addressId);
    if (!address) return null;
    
    return `${address.address || ''}${address.city ? `, ${address.city}` : ''}`;
  };

  // Calculate pagination
  const indexOfLastOrder = currentPage * itemsPerPage;
  const indexOfFirstOrder = indexOfLastOrder - itemsPerPage;
  const currentOrders = filteredOrders.slice(indexOfFirstOrder, indexOfLastOrder);
  const totalPages = Math.ceil(filteredOrders.length / itemsPerPage);

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('ALL');
    setDateRange(undefined);
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Orders</CardTitle>
          <CardDescription>View and track your orders</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-col space-y-3 md:flex-row md:items-center md:justify-between md:space-y-0">
            <Skeleton className="h-10 w-64" />
            <div className="flex space-x-2">
              <Skeleton className="h-10 w-32" />
              <Skeleton className="h-10 w-32" />
            </div>
          </div>
          
          <div className="border rounded-md">
            <div className="relative w-full overflow-auto">
              <Skeleton className="h-12 w-full" />
              <div className="space-y-1">
                {Array(5).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex items-center justify-between">
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-8 w-32" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Orders</CardTitle>
        <CardDescription>
          View and track your order history
          {userAddresses.length > 0 && ` - ${userAddresses.length} saved addresses`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Filter and Search Controls */}
        <div className="mb-4 flex flex-col space-y-3 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div className="flex items-center space-x-2 w-full md:w-1/3">
            <div className="relative w-full">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8"
              />
            </div>
          </div>
          
          <div className="flex flex-col space-y-2 md:flex-row md:space-x-2 md:space-y-0">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                {orderStatuses.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "justify-start text-left font-normal w-[240px]",
                    !dateRange?.from && !dateRange?.to && "text-muted-foreground"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "LLL dd, y")} -{" "}
                        {format(dateRange.to, "LLL dd, y")}
                      </>
                    ) : (
                      format(dateRange.from, "LLL dd, y")
                    )
                  ) : (
                    "Date range"
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <CalendarComponent
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                />
                <div className="flex items-center justify-between p-3 border-t">
                  <Button variant="ghost" size="sm" onClick={() => setDateRange(undefined)}>
                    Clear
                  </Button>
                  <Button size="sm" onClick={() => document.body.click()}>
                    Apply
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
            
            {(statusFilter !== 'ALL' || dateRange?.from || dateRange?.to || searchTerm) && (
              <Button variant="ghost" onClick={clearFilters} className="h-10">
                Clear Filters
              </Button>
            )}
          </div>
        </div>
        
        {filteredOrders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12">
            <ShoppingBag className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-xl font-medium">No orders found</h3>
            <p className="text-muted-foreground">
              {orders.length > 0 
                ? "Try adjusting your filters" 
                : "You haven't placed any orders yet"}
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {currentOrders.map((order) => (
              <div
                key={order.id}
                className="border rounded-lg overflow-hidden"
              >
                <div className="bg-muted p-4 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">
                        Order #{order.orderNumber || order.id}
                      </h3>
                      {order.orderStatus && (
                        <Badge 
                          className={getStatusColor(order.orderStatus)}
                        >
                          {order.orderStatus}
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {order.orderDate ? (
                        <>
                          <span className="mr-2">
                            {formatDate(order.orderDate)}
                          </span>
                        </>
                      ) : (
                        <span>No date available</span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {order.totalAmount && (
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Total</div>
                        <div className="font-semibold">
                          {formatCurrency(order.totalAmount)}
                        </div>
                      </div>
                    )}
                    <Link
                      href={`/account/orders/${order.id}`}
                      className={buttonVariants({ variant: "outline", size: "sm" })}
                    >
                      View Details
                    </Link>
                  </div>
                </div>
                <div className="p-4">
                  <div className="divide-y">
                    {ordersHaveItems(order) ? (
                      order.orderItems.map((item, index) => (
                        <div
                          key={index}
                          className="py-4 first:pt-0 last:pb-0 flex items-start gap-4"
                        >
                          <div className="relative w-16 h-16 rounded-lg overflow-hidden border flex-shrink-0">
                            {getItemImage(item) ? (
                              <Image
                                src={getItemImage(item)}
                                alt={item.product?.name || 'Product'}
                                fill
                                className="object-cover"
                              />
                            ) : (
                              <div className="w-full h-full bg-muted flex items-center justify-center">
                                <Package2 className="h-8 w-8 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="font-medium">
                              {item.product?.name || 'Product Name Not Available'}
                            </div>
                            {item.quantity && (
                              <div className="text-sm text-muted-foreground">
                                Qty: {item.quantity}
                              </div>
                            )}
                            {item.itemPrice && (
                              <div className="text-sm font-medium">
                                {formatCurrency(item.itemPrice)}
                              </div>
                            )}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="py-4 text-center text-muted-foreground">
                        Order details not available
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        {/* Pagination */}
        {filteredOrders.length > itemsPerPage && (
          <div className="mt-6 flex justify-center">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1}
              >
                <ChevronsLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage - 1)}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <span className="text-sm text-muted-foreground px-2">
                Page {currentPage} of {totalPages}
              </span>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages}
              >
                <ChevronsRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
} 