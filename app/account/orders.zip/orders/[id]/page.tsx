'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/skeleton'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { 
  ArrowLeft, 
  Package, 
  ShoppingBag, 
  Truck, 
  Phone,
  User,
  Mail,
  MapPin,
  CreditCard,
  Calendar,
  Download,
  CircleCheck,
  CircleDashed,
  CircleDot,
  Home
} from 'lucide-react'

interface ProductDetails {
  id: number
  name: string
  mainImage: string
}

interface VariationCombination {
  id: number
  imageUrl: string | null
  price: string | null
  variation1: {
    name: string
    value: string
  }
  variation2?: {
    name: string
    value: string
  } | null
  variation3?: {
    name: string
    value: string
  } | null
}

interface AddressInfo {
  id: number
  fullName: string | null
  mobileNo: string | null
  address: string | null
  city: string | null
  isDefault?: boolean
}

interface OrderItem {
  id: number
  productId: number | null
  quantity: number | null
  itemPrice: string | null
  product: ProductDetails | null
  product_variation_combinations: VariationCombination | null
  variationDetails: string | null
}

interface Order {
  id: number
  orderNumber: string
  orderDate: string | null
  totalAmount: string | null
  orderStatus: string | null
  shippingMethod: string | null
  shippingCharge: string | null
  subtotal: string | null
  fullName: string | null
  mobileNo: string | null
  email: string | null
  shippingAddress: AddressInfo | null
  billingAddress: AddressInfo | null
  payments: Array<{
    id: number
    paymentMethod: string
    paymentAmount: string | null
    paymentDate: string | null
  }>
  orderItems: OrderItem[]
}

export default function OrderDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [order, setOrder] = useState<Order | null>(null);
  const [userAddresses, setUserAddresses] = useState<AddressInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/orders/${params.id}`);
        
        if (!response.ok) {
          if (response.status === 404) {
            router.push('/account/orders');
            return;
          }
          throw new Error('Failed to fetch order');
        }
        
        const data = await response.json();
        setOrder(data.order);
        
        // Save user addresses if available
        if (data.userAddresses) {
          setUserAddresses(data.userAddresses);
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching order:', error);
        setLoading(false);
      }
    };

    if (params.id) {
      fetchOrder();
    }
  }, [params.id, router]);

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount: string | null) => {
    if (!amount) return '$0.00';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(parseFloat(amount));
  };

  // Get status color
  const getStatusColor = (status: string | null) => {
    if (!status) return 'bg-gray-500';
    
    const statusMap: Record<string, string> = {
      'PENDING': 'bg-yellow-500',
      'PROCESSING': 'bg-blue-500',
      'SHIPPED': 'bg-purple-500',
      'DELIVERED': 'bg-green-500',
      'CANCELLED': 'bg-red-500',
    };
    return statusMap[status] || 'bg-gray-500';
  };

  // Format address for display
  const formatAddress = (address: AddressInfo | null): string => {
    if (!address) return 'No address information available';
    
    const parts = [];
    if (address.address) parts.push(address.address);
    if (address.city) parts.push(address.city);
    
    return parts.join(', ') || 'No address details available';
  };

  // Get variation string
  const getVariationString = (combination: VariationCombination | null, variationDetails: string | null): string => {
    // Try from combination first
    if (combination) {
      const variations = [];
      
      if (combination.variation1) {
        variations.push(`${combination.variation1.name}: ${combination.variation1.value}`);
      }
      
      if (combination.variation2) {
        variations.push(`${combination.variation2.name}: ${combination.variation2.value}`);
      }
      
      if (combination.variation3) {
        variations.push(`${combination.variation3.name}: ${combination.variation3.value}`);
      }
      
      return variations.join(', ');
    }
    
    // Then try from variationDetails
    if (variationDetails) {
      try {
        const details = JSON.parse(variationDetails);
        if (details.name && details.value) {
          return `${details.name}: ${details.value}`;
        }
      } catch (e) {
        // If parsing fails, ignore
      }
    }
    
    return '';
  };

  // Get item image
  const getItemImage = (orderItem: OrderItem): string => {
    // First try to get the variation combination image
    if (orderItem.product_variation_combinations?.imageUrl) {
      return orderItem.product_variation_combinations.imageUrl;
    }
    
    // Then try to get the product image
    if (orderItem.product?.mainImage) {
      return orderItem.product.mainImage;
    }
    
    // If still no image, check variationDetails (legacy format)
    if (orderItem.variationDetails) {
      try {
        const details = JSON.parse(orderItem.variationDetails);
        if (details.image) {
          return details.image;
        }
      } catch (e) {
        // If parsing fails, ignore and use fallback
      }
    }
    
    // Fallback - no image available
    return '';
  };

  // Get order progress steps
  const getOrderSteps = (status: string | null) => {
    const steps = [
      { name: 'Order Placed', status: 'PENDING', icon: Package },
      { name: 'Processing', status: 'PROCESSING', icon: CircleDashed },
      { name: 'Shipped', status: 'SHIPPED', icon: Truck },
      { name: 'Delivered', status: 'DELIVERED', icon: CircleCheck }
    ];
    
    if (!status || status === 'CANCELLED') {
      return steps.map(step => ({
        ...step,
        completed: false,
        active: false
      }));
    }
    
    const currentStepIndex = steps.findIndex(step => step.status === status);
    
    return steps.map((step, index) => ({
      ...step,
      completed: index < currentStepIndex,
      active: index === currentStepIndex
    }));
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <Skeleton className="h-8 w-8" />
          <Skeleton className="h-6 w-32" />
        </div>
        
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-48 mb-2" />
            <Skeleton className="h-4 w-64" />
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Skeleton className="h-32" />
                <Skeleton className="h-32" />
              </div>
              <Skeleton className="h-64" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="text-center py-12">
        <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">Order not found</h3>
        <p className="text-muted-foreground mb-4">
          The order you are looking for does not exist or has been removed.
        </p>
        <Button asChild>
          <Link href="/account/orders">Back to Orders</Link>
        </Button>
      </div>
    );
  }

  const orderSteps = getOrderSteps(order.orderStatus);

  return (
    <div className="space-y-6">
      <div>
        <Button variant="ghost" className="mb-4" asChild>
          <Link href="/account/orders">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Orders
          </Link>
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle>Order #{order.orderNumber || order.id}</CardTitle>
              <CardDescription>Placed on {formatDate(order.orderDate)}</CardDescription>
            </div>
            <Badge className={getStatusColor(order.orderStatus)}>
              {order.orderStatus}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            {/* Order Progress Tracker - only show if not cancelled */}
            {order.orderStatus !== 'CANCELLED' && (
              <div className="mb-8">
                <h3 className="text-lg font-medium mb-4">Order Progress</h3>
                <div className="relative flex justify-between">
                  {/* Progress bar */}
                  <div className="absolute top-5 left-0 right-0 h-1 bg-muted">
                    <div 
                      className="h-full bg-primary" 
                      style={{ 
                        width: `${orderSteps.filter(step => step.completed || step.active).length / orderSteps.length * 100}%` 
                      }}
                    />
                  </div>
                  
                  {/* Steps */}
                  {orderSteps.map((step, index) => (
                    <div key={step.name} className="relative flex flex-col items-center">
                      <div 
                        className={`relative z-10 flex h-10 w-10 items-center justify-center rounded-full 
                          ${step.completed 
                            ? 'bg-primary text-primary-foreground' 
                            : step.active 
                              ? 'bg-primary text-primary-foreground ring-4 ring-primary/20' 
                              : 'bg-muted text-muted-foreground'
                          }`}
                      >
                        <step.icon className="h-5 w-5" />
                      </div>
                      <span className="mt-2 text-sm font-medium">{step.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Customer and Order Info */}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {/* Customer Information */}
              <div>
                <h3 className="text-lg font-medium mb-4">Customer Information</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <User className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">{order.fullName}</p>
                    </div>
                  </div>
                  
                  {order.mobileNo && (
                    <div className="flex items-start space-x-3">
                      <Phone className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p>{order.mobileNo}</p>
                      </div>
                    </div>
                  )}
                  
                  {order.email && (
                    <div className="flex items-start space-x-3">
                      <Mail className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p>{order.email}</p>
                      </div>
                    </div>
                  )}
                  
                  {userAddresses.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Your Saved Addresses ({userAddresses.length})</h4>
                      <div className="space-y-2">
                        {userAddresses.slice(0, 2).map(address => (
                          <div key={address.id} className="flex items-start space-x-3">
                            <Home className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
                            <div className="text-sm">
                              <p className="font-medium">{address.fullName}</p>
                              <p>{formatAddress(address)}</p>
                            </div>
                          </div>
                        ))}
                        {userAddresses.length > 2 && (
                          <p className="text-sm text-muted-foreground">
                            +{userAddresses.length - 2} more addresses
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Shipping Info */}
              <div>
                <h3 className="text-lg font-medium mb-4">Shipping Information</h3>
                <div className="space-y-3">
                  {order.shippingAddress && (
                    <div className="flex items-start space-x-3">
                      <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">{order.shippingAddress.fullName || order.fullName}</p>
                        <p>{order.shippingAddress.mobileNo || order.mobileNo}</p>
                        <p>{formatAddress(order.shippingAddress)}</p>
                      </div>
                    </div>
                  )}
                  
                  {!order.shippingAddress && order.fullName && (
                    <div className="flex items-start space-x-3">
                      <MapPin className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">{order.fullName}</p>
                        {order.mobileNo && <p>{order.mobileNo}</p>}
                        <p className="text-muted-foreground">No detailed address information available</p>
                      </div>
                    </div>
                  )}
                  
                  {order.billingAddress && order.billingAddress.id !== order.shippingAddress?.id && (
                    <div className="flex items-start space-x-3">
                      <Home className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">Billing Address</p>
                        <p>{order.billingAddress.fullName || order.fullName}</p>
                        <p>{formatAddress(order.billingAddress)}</p>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex items-start space-x-3">
                    <Truck className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Shipping Method</p>
                      <p className="capitalize">{order.shippingMethod || 'Standard Shipping'}</p>
                    </div>
                  </div>
                  
                  {order.payments && order.payments.length > 0 && (
                    <div className="flex items-start space-x-3">
                      <CreditCard className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
                      <div>
                        <p className="font-medium">Payment Method</p>
                        <p className="capitalize">{order.payments[0].paymentMethod}</p>
                        {order.payments[0].paymentDate && (
                          <p className="text-sm text-muted-foreground">
                            Paid on {formatDate(order.payments[0].paymentDate)}
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Order Items */}
            <div>
              <h3 className="text-lg font-medium mb-4">Order Items</h3>
              <div className="border rounded-md">
                {order.orderItems.map((item, index) => {
                  const itemImage = getItemImage(item);
                  const variationString = getVariationString(item.product_variation_combinations, item.variationDetails);
                  
                  return (
                    <div key={item.id}>
                      <div className="p-4 flex flex-col md:flex-row md:items-center">
                        <div className="flex items-center space-x-4 flex-1">
                          <div className="h-16 w-16 flex-shrink-0">
                            {item.productId && (
                              <Link href={`/shop/product/${item.productId}`}>
                                {itemImage ? (
                                  <img 
                                    src={itemImage} 
                                    alt=""
                                    className="h-full w-full object-cover rounded-md border"
                                  />
                                ) : (
                                  <div className="h-full w-full bg-muted rounded-md flex items-center justify-center">
                                    <ShoppingBag className="h-6 w-6 text-muted-foreground" />
                                  </div>
                                )}
                              </Link>
                            )}
                            {!item.productId && (
                              <div className="h-full w-full bg-muted rounded-md flex items-center justify-center">
                                <ShoppingBag className="h-6 w-6 text-muted-foreground" />
                              </div>
                            )}
                          </div>
                          
                          <div className="flex-1">
                            {item.productId ? (
                              <Link 
                                href={`/shop/product/${item.productId}`}
                                className="font-medium hover:underline"
                              >
                                {item.product?.name || 'Unknown Product'}
                              </Link>
                            ) : (
                              <h4 className="font-medium">{item.product?.name || 'Unknown Product'}</h4>
                            )}
                            {variationString && (
                              <p className="text-sm text-muted-foreground">{variationString}</p>
                            )}
                            <p className="text-sm">
                              Qty: {item.quantity || 1} x {formatCurrency(item.itemPrice)}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-4 md:mt-0 text-right">
                          <p className="font-medium">
                            {formatCurrency((item.quantity || 1) * parseFloat(item.itemPrice || '0'))}
                          </p>
                        </div>
                      </div>
                      
                      {index < order.orderItems.length - 1 && <Separator />}
                    </div>
                  );
                })}
              </div>
            </div>
            
            {/* Order Summary */}
            <div>
              <h3 className="text-lg font-medium mb-4">Order Summary</h3>
              <div className="border rounded-md p-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatCurrency(order.subtotal)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{formatCurrency(order.shippingCharge)}</span>
                  </div>
                  
                  <Separator className="my-2" />
                  
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>{formatCurrency(order.totalAmount)}</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/account/orders">
                  Return to Orders
                </Link>
              </Button>
              
              {order.orderStatus === 'DELIVERED' && (
                <Button>
                  <Download className="h-4 w-4 mr-2" />
                  Download Invoice
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
} 