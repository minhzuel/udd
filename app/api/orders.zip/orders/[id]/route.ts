import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { getSessionUserId } from '@/lib/session'

export async function GET(
  request: Request, 
  { params }: { params: { id: string } }
) {
  try {
    // Get user ID from session for authorization check
    const userId = await getSessionUserId(request)
    
    // Convert the ID parameter to a number
    const orderId = parseInt(params.id)
    
    if (isNaN(orderId)) {
      return NextResponse.json({ error: 'Invalid order ID' }, { status: 400 })
    }

    // Use the correct field names based on the schema
    const order = await prisma.order.findUnique({
      where: {
        id: orderId
      },
      select: {
        id: true,
        userId: true,
        orderDate: true,
        orderStatus: true,
        totalAmount: true,
        shipping_method: true,
        shipping_charge: true,
        subtotal: true,
        full_name: true,
        mobile_no: true,
        email: true,
        orderItems: {
          include: {
            product: {
              select: {
                id: true,
                name: true,
                mainImage: true
              }
            },
            product_variation_combinations: {
              select: {
                id: true,
                imageUrl: true,
                price: true,
                variation1: {
                  select: {
                    name: true,
                    value: true
                  }
                },
                variation2: {
                  select: {
                    name: true,
                    value: true
                  }
                },
                variation3: {
                  select: {
                    name: true,
                    value: true
                  }
                }
              }
            }
          }
        },
        OrderPayment: {
          select: {
            id: true,
            paymentMethod: true,
            paymentAmount: true,
            paymentDate: true
          }
        },
        shippingAddressId: true,
        billingAddressId: true
      }
    })

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    
    // Fetch addresses separately if they exist
    let shippingAddress = null;
    let billingAddress = null;
    
    if (order.shippingAddressId) {
      try {
        shippingAddress = await prisma.address.findUnique({
          where: { id: order.shippingAddressId },
          select: {
            id: true,
            fullName: true,
            mobileNo: true,
            address: true,
            city: true
          }
        });
      } catch (error) {
        console.error('Error fetching shipping address:', error);
      }
    }
    
    if (order.billingAddressId) {
      try {
        billingAddress = await prisma.address.findUnique({
          where: { id: order.billingAddressId },
          select: {
            id: true,
            fullName: true,
            mobileNo: true,
            address: true,
            city: true
          }
        });
      } catch (error) {
        console.error('Error fetching billing address:', error);
      }
    }
    
    // Get user addresses from database if user is authenticated and owns this order
    let userAddresses = [];
    if (userId && order.userId === userId) {
      try {
        userAddresses = await prisma.address.findMany({
          where: {
            userId: userId,
            isGuestAddress: false
          }
        });
      } catch (error) {
        console.error('Error fetching user addresses:', error);
      }
    }
    
    // Define default order status values for the UI if needed
    // This ensures we have a consistent status even if the database has different values
    const statusMapping = {
      'pending': 'PENDING',
      'processing': 'PROCESSING',
      'shipped': 'SHIPPED',
      'delivered': 'DELIVERED',
      'cancelled': 'CANCELLED'
    };
    
    // Format the order for the frontend
    const formattedOrder = {
      id: order.id,
      orderNumber: `ORD-${order.id.toString().padStart(6, '0')}`,
      orderDate: order.orderDate,
      // Map status to uppercase if it's one of our known statuses, otherwise preserve original
      orderStatus: order.orderStatus 
        ? (Object.keys(statusMapping).includes(order.orderStatus.toLowerCase())
            ? statusMapping[order.orderStatus.toLowerCase()]
            : order.orderStatus)
        : null,
      totalAmount: order.totalAmount?.toString(),
      shippingMethod: order.shipping_method,
      shippingCharge: order.shipping_charge?.toString(),
      subtotal: order.subtotal?.toString(),
      fullName: order.full_name,
      mobileNo: order.mobile_no,
      email: order.email,
      shippingAddress: shippingAddress,
      billingAddress: billingAddress,
      payments: order.OrderPayment || [],
      orderItems: order.orderItems || []
    };

    return NextResponse.json({ order: formattedOrder, userAddresses })
  } catch (error) {
    console.error('Error fetching order:', error)
    return NextResponse.json({ 
      error: 'Internal server error', 
      details: error.message 
    }, { status: 500 })
  }
} 