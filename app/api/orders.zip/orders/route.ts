import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { redeemRewardPoints } from '@/services/reward-points'
import jwt from 'jsonwebtoken'

interface OrderItem {
  id: number
  quantity: number
  price: number
  variation?: {
    id: number | null
    name: string
    value: string
    price: number
  }
  variationDetails?: string
}

export async function POST(request: Request) {
  try {
    // Check for existing session (logged in user)
    const cookieHeader = request.headers.get('cookie') || '';
    const cookies = cookieHeader.split(';').reduce((acc, cookie) => {
      const [key, value] = cookie.trim().split('=');
      acc[key] = value;
      return acc;
    }, {} as Record<string, string>);
    
    const sessionCookie = cookies['session'];
    let loggedInUserId = null;
    
    if (sessionCookie) {
      try {
        loggedInUserId = parseInt(sessionCookie);
        if (isNaN(loggedInUserId)) {
          loggedInUserId = null;
        } else {
          console.log('User is logged in with ID:', loggedInUserId);
        }
      } catch (e) {
        console.error('Error parsing session cookie:', e);
      }
    }

    let body;
    try {
      const rawBody = await request.text()
      console.log('Received raw request body:', rawBody)
      body = JSON.parse(rawBody)
      console.log('Parsed request body:', JSON.stringify(body, null, 2))
    } catch (parseError) {
      console.error('Failed to parse request body:', parseError)
      return NextResponse.json(
        { 
          error: 'Invalid request body',
          details: 'The request body must be valid JSON'
        },
        { status: 400 }
      )
    }

    // Validate required fields
    const requiredFields = ['fullName', 'email', 'mobile', 'shippingMethod', 'items', 'totalAmount']
    const missingFields = requiredFields.filter(field => !body[field])
    
    if (missingFields.length > 0) {
      console.error('Missing required fields:', missingFields)
      return NextResponse.json(
        { 
          error: 'Missing required fields',
          details: `Missing fields: ${missingFields.join(', ')}`
        },
        { status: 400 }
      )
    }

    // Validate address information
    if (loggedInUserId) {
      // For logged-in users, validate address IDs
      if (!body.shippingAddressId) {
        console.error('Missing shipping address ID for logged-in user')
        return NextResponse.json(
          { 
            error: 'Missing shipping address',
            details: 'Shipping address ID is required'
          },
          { status: 400 }
        )
      }
      
      if (!body.billingAddressId) {
        console.error('Missing billing address ID for logged-in user')
        return NextResponse.json(
          { 
            error: 'Missing billing address',
            details: 'Billing address ID is required'
          },
          { status: 400 }
        )
      }
    } else {
      // For guest users, validate address fields
      if (!body.address) {
        console.error('Missing address for guest user')
        return NextResponse.json(
          { 
            error: 'Missing address',
            details: 'Address is required for guest users'
          },
          { status: 400 }
        )
      }
    }

    if (!Array.isArray(body.items) || body.items.length === 0) {
      console.error('Invalid items array:', body.items)
      return NextResponse.json(
        { 
          error: 'Invalid items',
          details: 'Items must be a non-empty array'
        },
        { status: 400 }
      )
    }

    // Get all product IDs from the order items
    const productIds = body.items.map((item: OrderItem) => parseInt(item.id.toString()))
    console.log('Processing order for product IDs:', productIds)

    try {
      // Fetch all products in a single query
      const products = await prisma.product.findMany({
        where: {
          id: {
            in: productIds
          }
        },
        include: {
          ProductToVariation: {
            include: {
              product_variations: true
            }
          },
          variationCombinations: true
        }
      })

      console.log('Found products:', JSON.stringify(products, null, 2))

      // Check stock availability
      for (const item of body.items) {
        const itemId = parseInt(item.id.toString())
        const product = products.find(p => p.id === itemId)
        if (!product) {
          console.error('Product not found:', itemId)
          return NextResponse.json(
            { 
              error: 'Product not found',
              details: `Product with ID ${itemId} not found`
            },
            { status: 404 }
          )
        }

        // Check if the variation has a valid ID that needs stock checking
        if (item.variation && item.variation.id && parseInt(item.variation.id.toString()) > 0) {
          // Find the variation combination that matches the item
          const variationId = parseInt(item.variation.id.toString());
          const variationCombination = product.variationCombinations.find(combo => 
            combo.id === variationId
          );

          if (!variationCombination) {
            console.error('Variation combination not found:', {
              product: product.name,
              requestedVariationId: variationId,
              availableCombinations: product.variationCombinations.map(vc => ({
                id: vc.id
              }))
            })
            return NextResponse.json(
              { 
                error: 'Variation not found',
                details: `No matching variation found for product ${product.name} with ID: ${variationId}`
              },
              { status: 404 }
            )
          }

          if (variationCombination.stockQuantity < item.quantity) {
            console.error('Insufficient stock for variation:', {
              product: product.name,
              variation: variationCombination.id,
              requested: item.quantity,
              available: variationCombination.stockQuantity
            })
            return NextResponse.json(
              { 
                error: 'Insufficient stock',
                details: `Only ${variationCombination.stockQuantity} units available for variation of product ${product.name}`
              },
              { status: 400 }
            )
          }
        } else if (item.variation && item.variation.id === null) {
          // This is a descriptive variation only, not tied to inventory
          // Allow the order to proceed without checking variation stock
          console.log('Processing descriptive variation for product:', {
            product: product.name,
            variation: item.variation.name + ': ' + item.variation.value,
            usingMainProductStock: true
          });
          
          // Check main product stock since we can't check specific variation
          if (product.stockQuantity < item.quantity) {
            console.error('Insufficient stock for product:', {
              product: product.name,
              requested: item.quantity,
              available: product.stockQuantity
            })
            return NextResponse.json(
              { 
                error: 'Insufficient stock',
                details: `Only ${product.stockQuantity} units available for product ${product.name}`
              },
              { status: 400 }
            )
          }
        } else if (product.stockQuantity < item.quantity) {
          // If no variation ID, check main product stock
          console.error('Insufficient stock for product:', {
            product: product.name,
            requested: item.quantity,
            available: product.stockQuantity
          })
          return NextResponse.json(
            { 
              error: 'Insufficient stock',
              details: `Only ${product.stockQuantity} units available for product ${product.name}`
            },
            { status: 400 }
          )
        }
      }

      // Create order with items in a single transaction
      const order = await prisma.$transaction(async (tx) => {
        try {
          // For logged-in users, fetch the shipping and billing addresses
          let shippingAddress;
          let billingAddress;
          
          if (loggedInUserId) {
            // Fetch shipping address
            shippingAddress = await tx.address.findUnique({
              where: {
                id: body.shippingAddressId,
                userId: loggedInUserId
              }
            });
            
            if (!shippingAddress) {
              throw new Error(`Shipping address with ID ${body.shippingAddressId} not found for user ${loggedInUserId}`);
            }
            
            // Fetch billing address
            billingAddress = await tx.address.findUnique({
              where: {
                id: body.billingAddressId,
                userId: loggedInUserId
              }
            });
            
            if (!billingAddress) {
              throw new Error(`Billing address with ID ${body.billingAddressId} not found for user ${loggedInUserId}`);
            }
          } else {
            // For guest users, create new addresses
            shippingAddress = await tx.address.create({
              data: {
                address: body.address,
                city: body.city || '', // Default empty string for required field
                fullName: body.fullName,
                mobileNo: body.mobile,
                isGuestAddress: true
              }
            });
            
            // If billing address is different from shipping address
            if (body.billingAddress && body.billingAddress !== body.address) {
              billingAddress = await tx.address.create({
                data: {
                  address: body.billingAddress,
                  city: body.billingCity || '', 
                  fullName: body.fullName,
                  mobileNo: body.mobile,
                  isGuestAddress: true
                }
              });
            } else {
              // Use the same address for billing
              billingAddress = shippingAddress;
            }
          }

          // Use logged in user if available, otherwise check for existing user or create new one
          let userId = loggedInUserId;
          
          if (!userId) {
            // Check if a user exists with the provided email
            const existingUser = await tx.user.findFirst({
              where: { 
                email: body.email,
                isGuest: false // Only find real users, not guests
              }
            });

            if (existingUser) {
              // If user exists, associate the order with them
              userId = existingUser.id;
              console.log(`Found existing user with ID: ${userId}`);
            } else {
              // For guest checkout, we'll create a temporary user with minimal information
              const newUser = await tx.user.create({
                data: {
                  fullName: body.fullName,
                  email: body.email,
                  mobileNo: body.mobile,
                  isGuest: true, // Flag to indicate this is a guest account
                  userType: 'customer'
                }
              });
              userId = newUser.id;
              console.log(`Created guest user with ID: ${userId}`);
            }
          }

          // Fetch shipping method details
          let shippingMethodId: number;
          try {
            shippingMethodId = parseInt(body.shippingMethod);
            if (isNaN(shippingMethodId)) {
              throw new Error(`Invalid shipping method ID: ${body.shippingMethod}`);
            }
          } catch (error) {
            throw new Error(`Invalid shipping method ID: ${body.shippingMethod}`);
          }
          
          // Fetch shipping method details
          const shippingMethod = await tx.shippingMethod.findUnique({
            where: {
              id: shippingMethodId
            }
          })
          
          if (!shippingMethod) {
            throw new Error(`Shipping method with ID ${shippingMethodId} not found`)
          }
          
          const shippingCost = shippingMethod.base_cost ? parseFloat(shippingMethod.base_cost.toString()) : 0
          const subtotal = body.subtotal
          const totalAmount = body.totalAmount
          
          // Set the order date to now
          const orderDate = new Date()

          // Create the order
          const orderItems = body.items.map((item: OrderItem) => {
            const productId = parseInt(item.id.toString());
            let variations = null;
            let variationDetails = '';
            let combinationId = null;
            
            // Process variation if present
            if (item.variation) {
              variationDetails = item.variation.value;
              
              // Structured variation to save
              if (item.variation.id && parseInt(item.variation.id.toString()) > 0) {
                combinationId = parseInt(item.variation.id.toString());
              }
            }
            
            // Prepare the order item
            const orderItem: any = {
              product: {
                connect: {
                  id: productId
                }
              },
              quantity: item.quantity,
              itemPrice: item.variation && item.variation.price ? item.variation.price : item.price,
              variation_details: variationDetails
            };
            
            // Add variations if present
            if (variations) {
              orderItem.variations = variations;
            }
            
            // Add variation_combinationId if present
            if (combinationId) {
              orderItem.product_variation_combinations = {
                connect: {
                  id: combinationId
                }
              };
            }
            
            return orderItem;
          });

          // Validate reward points if being used
          if (body.rewardPointsUsed && body.rewardPointsUsed > 0) {
            // Validate that the user is logged in to use reward points
            if (!userId) {
              return NextResponse.json(
                { error: 'Must be logged in to use reward points' },
                { status: 400 }
              )
            }
            
            // Calculate discount amount (100 points = $1)
            const pointsDiscount = body.rewardPointsUsed / 100
            
            // Ensure discount isn't more than 90% of the order total
            const maxDiscount = body.subtotal * 0.9
            if (pointsDiscount > maxDiscount) {
              return NextResponse.json(
                { error: 'Cannot apply more than 90% discount using reward points' },
                { status: 400 }
              )
            }
          }

          const newOrder = await tx.order.create({
            data: {
              user: {
                connect: {
                  id: userId
                }
              },
              orderDate,
              subtotal,
              totalAmount,
              shippingCharge: shippingCost,
              shippingAddress: {
                connect: {
                  id: shippingAddress.id
                }
              },
              billingAddress: {
                connect: {
                  id: billingAddress.id
                }
              },
              shipping_method: shippingMethod.name,
              orderStatus: 'PENDING',
              fullName: body.fullName,
              mobileNo: body.mobile,
              email: body.email,
              // Apply reward points data if used
              rewardPointsUsed: body.rewardPointsUsed || 0,
              rewardPointsDiscount: body.pointsDiscount || 0,
              orderItems: {
                create: orderItems
              }
            },
            include: {
              orderItems: true,
              payments: true
            }
          })

          console.log('Order created successfully:', JSON.stringify(newOrder, null, 2))

          // Update stock quantities
          for (const item of body.items) {
            const productId = parseInt(item.id.toString());
            
            // Check if the variation has a valid ID that needs stock updating
            if (item.variation && item.variation.id && parseInt(item.variation.id.toString()) > 0) {
              const combinationId = parseInt(item.variation.id.toString());
              console.log(`Reducing stock for variation combination ID: ${combinationId} by ${item.quantity} units`);
              
              // Update variation stock
              await tx.productVariationCombination.update({
                where: {
                  id: combinationId
                },
                data: {
                  stockQuantity: {
                    decrement: item.quantity
                  }
                }
              });
            } else {
              // No valid variation ID, update inventory for the main product
              const inventoryItem = await tx.inventory.findFirst({
                where: {
                  productId: productId
                }
              });
              
              if (inventoryItem) {
                // Update existing inventory
                await tx.inventory.update({
                  where: {
                    id: inventoryItem.id
                  },
                  data: {
                    quantity: {
                      decrement: item.quantity
                    }
                  }
                });
                
                // Record the movement
                await tx.inventoryMovement.create({
                  data: {
                    inventoryId: inventoryItem.id,
                    movementType: 'out',
                    quantity: item.quantity,
                    movementDate: new Date(),
                    referenceType: 'order',
                    reference_id: newOrder.id
                  }
                });
              } else {
                // If no inventory record exists, create one with negative quantity
                // to track that inventory needs to be reconciled
                console.warn(`No inventory record found for product ID ${productId}. Creating record with negative quantity.`);
                const newInventory = await tx.inventory.create({
                  data: {
                    productId: productId,
                    quantity: -item.quantity,
                    reorderLevel: 5 // default reorder level
                  }
                });
                
                // Record the movement
                await tx.inventoryMovement.create({
                  data: {
                    inventoryId: newInventory.id,
                    movementType: 'out',
                    quantity: item.quantity,
                    movementDate: new Date(),
                    referenceType: 'order',
                    reference_id: newOrder.id
                  }
                });
              }
            }
          }

          // If user is redeming reward points, apply the redemption
          if (userId && body.rewardPointsUsed && body.rewardPointsUsed > 0) {
            try {
              // Redeem the points, linking them to this order
              await redeemRewardPoints(userId, body.rewardPointsUsed, newOrder.id)
              console.log(`Redeemed ${body.rewardPointsUsed} points for order #${newOrder.id}`)
            } catch (rewardError) {
              // Log error but don't fail the order
              console.error('Failed to redeem reward points:', rewardError)
            }
          }

          // Award reward points immediately at order creation time for logged-in users
          if (userId) {
            try {
              console.log(`Adding reward points directly within transaction for order #${newOrder.id}, user #${userId}`);
              
              // Format order items for reward points calculation
              const formattedItems = newOrder.orderItems.map(item => ({
                id: item.id,
                productId: item.productId,
                quantity: item.quantity || 1,
                price: Number(item.itemPrice || 0)
              }));
              
              if (formattedItems.length === 0) {
                console.warn('No order items found for reward points calculation');
              } else {
                // Calculate points (simple calculation)
                // 5 points per item plus quantity bonuses
                let totalPoints = 0;
                
                for (const item of formattedItems) {
                  const basePoints = 5 * item.quantity;
                  let bonusPoints = 0;
                  
                  // Add quantity bonus
                  if (item.quantity >= 10) {
                    bonusPoints = 25; // Bonus for 10+ items
                  } else if (item.quantity >= 3) {
                    bonusPoints = 15; // Bonus for 3-9 items
                  }
                  
                  totalPoints += basePoints + bonusPoints;
                }
                
                // 1% of order total as additional points
                const orderAmount = Number(newOrder.totalAmount || 0);
                totalPoints += Math.floor(orderAmount * 0.01);
                
                console.log(`Calculated ${totalPoints} reward points for order #${newOrder.id}`);
                
                // Set expiry date to 90 days from now
                const expiryDate = new Date();
                expiryDate.setDate(expiryDate.getDate() + 90);
                
                // Create reward point record directly within the transaction
                const rewardPoint = await tx.rewardPoint.create({
                  data: {
                    userId: userId,
                    orderId: newOrder.id,
                    points: totalPoints,
                    earnedDate: new Date(),
                    expiryDate: expiryDate,
                    isUsed: false
                  }
                });
                
                console.log(`Successfully created reward point with ID: ${rewardPoint.id}`);
                
                // Create reward point detail
                const rewardPointDetail = await tx.reward_point_details.create({
                  data: {
                    reward_point_id: rewardPoint.id,
                    points: totalPoints,
                    points_description: `Order #${newOrder.id} reward points (${formattedItems.length} items)`
                  }
                });
                
                console.log(`Created reward point detail with ID: ${rewardPointDetail.detail_id}`);
              }
            } catch (rewardError) {
              // Log error but don't fail the order
              console.error('Error creating reward points in transaction:', rewardError);
            }
          } else {
            console.log(`No reward points awarded - order ${newOrder.id} has no user ID`);
          }

          return newOrder
        } catch (txError) {
          console.error('Transaction error:', txError)
          throw new Error(`Transaction failed: ${txError instanceof Error ? txError.message : 'Unknown error'}`)
        }
      })

      return NextResponse.json({ 
        order,
        message: 'Order created successfully'
      })
    } catch (dbError) {
      console.error('Database error:', dbError)
      return NextResponse.json(
        { 
          error: 'Database error',
          details: dbError instanceof Error ? dbError.message : 'Unknown database error occurred'
        },
        { status: 500 }
      )
    }
  } catch (error) {
    console.error('Order creation error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to create order',
        details: error instanceof Error ? error.message : 'Unknown error occurred'
      },
      { status: 500 }
    )
  }
} 